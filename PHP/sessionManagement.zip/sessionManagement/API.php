<?php
/**
 * Created by PhpStorm.
 * User: abanna
 * Date: 8/14/2017
 * Time: 8:57 AM
 */

$arr= Array(
   "emp1"=>array(
    'name'=>'abed',
    'password'=>'123'
   ),

    "emp2"=>array(
        'name'=>'ali',
        'password'=>'123'
    ),
    "emp3"=>array(
        'name'=>'salem',
        'password'=>'123'
    ));

echo json_encode($arr);
