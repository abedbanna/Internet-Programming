<?php
/**
 * Created by PhpStorm.
 * User: abanna
 * Date: 8/13/2017
 * Time: 8:42 AM
 */
include_once "db.php";