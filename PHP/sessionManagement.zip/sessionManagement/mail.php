<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "auth";


session_start();
if(!isset($_SESSION['user_id']))
    header("Location:login.html");


// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}





#step 2 Execute Sql
if($_SESSION['role']==0)
$sql="select * from emails where user_id=".$_SESSION['user_id'];
else
    $sql="select * from emails";

//echo $sql;
$result = $conn->query($sql);
#3- handle results
if ($result->num_rows > 0) {
// output data of each row
    while($row = $result->fetch_assoc()) {

echo $row['title']."----------".$row['descr']."<br>";


    }
} else {
    echo "No Data";
}
//4- Close Connection
$conn->close();

?>
<a href="signout.php">Signout</a>
