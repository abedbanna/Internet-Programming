<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "auth";


session_start();
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$uname=$_GET['u'];
$pass=$_GET['p'];



$ok=1;
#step 2 Execute Sql
$sql ="select * from users where username='$uname' and password='$pass'";

//echo $sql;
$result = $conn->query($sql);
#3- handle results
if ($result->num_rows > 0) {
// output data of each row
    while($row = $result->fetch_assoc()) {
        //echo "id: " . $row["empno"]. " - Name: " . $row["ename"]. " salary " . $row["sal"]. "

        {
$_SESSION['username']=$row['username'];
$_SESSION['role']=$row['role'];
$_SESSION['user_id']=$row['id'];
           // header("Location: mail.php");

        }

    }
} else {
  //  header("Location: login.html");
$ok=0;
}

//4- Close Connection
$conn->close();
echo json_encode($ok);
?>