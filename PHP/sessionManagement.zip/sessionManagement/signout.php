<?php
/**
 * Created by PhpStorm.
 * User: abanna
 * Date: 8/13/2017
 * Time: 9:03 AM
 */
session_start();
session_unset();
session_destroy();

header("Location: login.html");
