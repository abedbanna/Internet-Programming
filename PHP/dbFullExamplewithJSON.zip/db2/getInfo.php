<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "empdb";
$id=$_GET['id'];

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// 2- Execute Sql Command
$sql = "SELECT empno,ename,sal FROM emp where empno=" .$id;
$result = $conn->query($sql);

//3-handle Results
$ok=0;
$emp="";
$i=0;
if ($result->num_rows > 0) {
// output data of each row

   $ok=1;
    }
 else {
   // echo "0 results";
}
echo json_encode($ok);

//4-Close connection
$conn->close();