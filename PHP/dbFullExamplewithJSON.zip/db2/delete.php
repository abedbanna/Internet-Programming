<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "empdb";


$empno=$_GET['empno'];


// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "delete from emp where empno=".$empno;

echo $sql;
if ($conn->query($sql) === TRUE) {
    header("Location:/db2/allEmps.php");
} else {
    echo "Error: " . $sql . "
" . $conn->error;
}

$conn->close();