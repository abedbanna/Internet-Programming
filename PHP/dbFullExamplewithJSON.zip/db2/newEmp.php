<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "empdb";


$empno=$_GET['txtEmpno'];
$ename=$_GET['txtEname'];
$sal=$_GET['txtSal'];
$dept=$_GET['txtDept'];

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "insert into emp(empno,ename,sal,deptno) values(".$empno.",'".$ename."',".$sal.",".$dept.")";
echo $sql;
if ($conn->query($sql) === TRUE) {
    header("Location:/db2/allEmps.php");
} else {
    echo "Error: " . $sql . "
" . $conn->error;
}

$conn->close();