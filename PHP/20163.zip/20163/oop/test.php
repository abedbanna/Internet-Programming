<?php
/**
 * Created by PhpStorm.
 * User: abanna
 * Date: 8/8/2017
 * Time: 8:34 AM
 */
require_once("Student.php");
$s1=new Student(7788,"Salem","12/12/2000","Male");
echo "User id is ".$s1->getId()."<br>";
echo "User name is ".$s1->getName()."<br>";
echo "User dob is ".$s1->getDob()."<br>";
echo "User gender is ".$s1->getgender()."<br>";