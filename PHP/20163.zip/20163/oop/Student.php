<?php

/**
 * Created by PhpStorm.
 * User: abanna
 * Date: 8/8/2017
 * Time: 8:33 AM
 */
require_once ("Person.php");
class Student extends Person
{

function __construct($id,$name,$dob,$gender)
{
parent::setId($id);
parent::setName($name);
parent::setDob($dob);
parent::setGender($gender);


}

}