<?php

/**
 * Created by PhpStorm.
 * User: abanna
 * Date: 8/8/2017
 * Time: 8:28 AM
 */
class Person
{
private $id=0;
private $name="";
private $dob="";
private $gender="male";

public function setId($id)
{
    $this->id=$id;

}
public function getId()
{
    $id= $this->id;
    return $id;
}

    public function setName($name)
    {
        $this->name=$name;

    }
    public function getName()
    {
        $name= $this->name;
        return $name;
    }

    public function setDob($dob)
    {
        $this->dob=$dob;

    }
    public function getDob()
    {
        $dob= $this->dob;
        return $dob;
    }

    public function setGender($gender)
    {
        $this->gender=$gender;

    }
    public function getGender()
    {
        $gender= $this->gender;
        return $gender;
    }

}