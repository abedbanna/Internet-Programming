function add()
{
    var no1=parseFloat(document.frm.txtNo1.value);
    var no2=parseFloat(document.frm.txtNo2.value);
    document.frm.txtResult.value=(no1+no2);
}

function div()
{
    var no1=parseFloat(document.frm.txtNo1.value);
    var no2=parseFloat(document.frm.txtNo2.value);
    document.frm.txtResult.value=(no1/no2);
}
function sub()
{
    var no1=parseFloat(document.frm.txtNo1.value);
    var no2=parseFloat(document.frm.txtNo2.value);
    document.frm.txtResult.value=(no1-no2);
}
function mul()
{
    var no1=parseFloat(document.frm.txtNo1.value);
    var no2=parseFloat(document.frm.txtNo2.value);
    document.frm.txtResult.value=(no1*no2);
}/**
 * Created by abanna on 7/17/2017.
 */
