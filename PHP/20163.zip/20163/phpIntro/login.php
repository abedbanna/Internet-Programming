<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login Page</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>

    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>

<?php
if(isset($_POST['txtUsername']) && isset($_POST['txtPassword'])) {
    $username = $_POST['txtUsername'];
    $password = $_POST['txtPassword'];
    $role=$_POST['cboRole'];
    $users=array(
        'Scott'=>array(
            'password'=>'123',
            'name'=>'Scott Tiger',

        )  ,
        'Smith'=>array(
            'password'=>'123',
            'name'=>'Smith Tiger',
        )
    ,'King'=>array(
            'password'=>'123',
            'name'=>'King Tiger',
        )
    );

    if (isset($users[$username]))
    {
        if($users[$username]['password']==$password)
        {
         if($role=="A")
            header("Location: /20163/phpIntro/admin.php?name=".$users[$username]['name']);
         else
             header("Location: /20163/phpIntro/user.php");
            die();
        }

    }
}

//to do task


?>


<div class="container-fluid">
    <div class="row">
        <div class="col-md-4">

        </div>
        <div class="col-md-4">

                <!--Start Form-->
                <form action="login.php" method="post" >
                    <div class="form-group">
                        <label for="txtUser">Username</label>
                        <input type="text" class="form-control" id="txtUser" name="txtUsername">
                    </div>

                    <div class="form-group">
                        <label for="txtPass">Password</label>
                        <input type="password" class="form-control" id="txtPass" name="txtPassword">
                    </div>

                    <div class="form-group">
                        <label for="cboRole">Role</label>
                        <select id="cboRole" name="cboRole" class="form-control">
                            <option value="A">Admin</option>
                            <option value="U">User</option>

                        </select>


                    </div>


                    <div class="form-group">
                       <input type="submit" value="Login" class="btn btn-success btn-lg">
                        <input type="reset" value="Cancel" class="btn btn-danger btn-lg">
                    </div>


                </form>
                <!--End Form-->

        </div>
    </div>
</div>


</body>
</html>