<?php
/**
 * Created by PhpStorm.
 * User: abanna
 * Date: 7/31/2017
 * Time: 8:24 AM
 */

//$emps=array("Scott","Smith","King");

/*$emps=array(
  'Scott'=>2000,
    'Smith'=>1500,
    'King'=>5000
);*/

$emps=array(
  'Scott'=>array(
      'id'=>7788,
      'name'=>'Scott',
      'salary'=>1500
  )  ,
    'Smith'=>array(
        'id'=>7878,
        'name'=>'Smith',
        'salary'=>1500
    )
,'King'=>array(
        'id'=>8877,
        'name'=>'King',
        'salary'=>1500
    )
);

/*foreach ($emps['Scott'] as $emp):
echo $emp."<br>";
endforeach;*/
echo json_encode($emps);
