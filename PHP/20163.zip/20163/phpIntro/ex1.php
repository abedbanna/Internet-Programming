<html>
<body>
<?php
/**
 * Created by PhpStorm.
 * User: abanna
 * Date: 7/30/2017
 * Time: 8:57 AM
 */

//$n=$_GET['txtValue'];
$n=$_POST['txtValue'];
$f=1;
for($x=1;$x<=$n;$x++)
    $f*=$x;
?>

<h1>the Factorial is: <?php echo $f;?></h1>
</body>
</html>


