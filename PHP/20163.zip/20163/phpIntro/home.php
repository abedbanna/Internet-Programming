<html>
<head>
    <title>PHP Example</title>
</head>
<body>

<h1>
    <?php
    $x="Welcome in PHP";
    echo $x;
    ?>

</h1>
</body>
</html>


