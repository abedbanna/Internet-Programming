<html>
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>

    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<?php
$key="";
if (isset($_GET['txtKey']))
    $key=$_GET['txtKey'];

?>
</head>


<body>
<form action="search.php">
<div class="container-fluid">
    <div class="row">
        <div class="col-md-4">

        </div>
        <div class="col-md-4">
            <input  type="search" name="txtKey" placeholder="key value" class="form-control" value=<?php echo $key;?>>
        <input type="submit" class="btn btn-info">
        </div>

    </div>
    <div class="row">
        <table class="table table-hover">
            <thead>
            <tr>
                <td>Id</td>
                <td>Name</td>
                <td>Salary</td>
            </tr>
            </thead>
<tr>
    <?php

    $emps=array(
        'Scott'=>array(
            'id'=>7788,
            'name'=>'Scott',
            'salary'=>1500
        )  ,
        'Smith'=>array(
            'id'=>7878,
            'name'=>'Smith',
            'salary'=>1500
        )
    ,'King'=>array(
            'id'=>8877,
            'name'=>'King',
            'salary'=>1500
        )
    );
    if (isset($_GET['txtKey'])) {
        $key = $_GET['txtKey'];
        echo "<td>".$emps[$key]['id']."</td>";
        echo "<td>".$emps[$key]['name']."</td>";
        echo "<td>".$emps[$key]['salary']."</td>";

    }
    ?>

</tr>


        </table>
    </div>
</div>
</form>
</body>
</html>