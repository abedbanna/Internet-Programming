<html>
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>

    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

</head>
<?php
include "db.php";
$sql="";
if(!isset($_GET['txtKey']))
$sql = "select empno,employee.name as ename,salary,job,department.name as dname from employee,department where employee.deptno=department.deptno";
else
    //$sql = "select * from employee WHERE empno=".$_GET['txtKey'];

$sql = "select empno,employee.name as ename,salary,job,department.name as dname from employee,department where employee.deptno=department.deptno and employee.name like'%".$_GET['txtKey']."%'";;

//echo $sql;
$result = $conn->query($sql);
?>

<body>
<header>
    <nav>
       <?php
       include "header.php";
       ?>
    </nav>
</header>
<form action="allemps.php">
    <div class="container-fluid">



        <div class="row">
            <input type="search" name="txtKey"  class="form-control">
            <input type="submit" value="Search" class="btn btn-info">
            <table class="table table-hover">
                <thead>

                <tr>
                    <td>No</td>
                    <td>Name</td>
                    <td>Salary</td>
                    <td>Job</td>
                    <td>Dept</td>
                </tr>
                </thead>

<?php
if ($result->num_rows > 0) {
// output data of each row
while($row = $result->fetch_assoc()) {
        echo "<tr><td>".$row['empno']."</td>";
        echo "<td>".$row['ename']."</td>";
        echo "<td>".$row['salary']."</td>";
        echo "<td>".$row['job']."</td>";
        echo "<td>".$row['dname']."</td></tr>";
    }


} else {
    echo "0 results";
}
$conn->close();
?>




            </table>
        </div>
    </div>
</form>
</body>
</html>