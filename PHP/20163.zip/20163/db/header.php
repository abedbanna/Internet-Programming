<ul class="nav nav-pills">
    <li role="presentation" class="active"><a href="allemps.php">All Emp</a></li>
    <li role="presentation"><a href="addEmp.php">Add New Employee</a></li>
    <li role="presentation"><a href="updateEmp.php">Update Employee</a></li>
    <li role="presentation"><a href="deleteEmp.php">Delete Employee</a></li>
</ul>