<html>

<?php
include "db.php";

$id="";
$ename="";
$salary="";
$job="";
$deptno="";


if(isset($_POST['txtId'])) {

    $sql = "select empno,name,salary,job,deptno from employee where empno=".$_POST['txtId'];
//echo $sql;
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
// output data of each row
        while($row = $result->fetch_assoc()) {
              $id=$row['empno'];
              $ename=$row['name'];
              $salary=$row['salary'];
              $job=$row['job'];
            $deptno=$row['deptno'];
        }


    } else {
        echo "0 results";
    }




}
if(isset($_POST['txtId']) && isset($_POST['txtName']) &&$_POST['txtSalary'])
{
    $id = $_POST["txtId"];
    $ename = $_POST['txtName'];
    $salary = $_POST['txtSalary'];
    $job = $_POST['txtJob'];
    $deptno = $_POST['txtDept'];

    $sql="UPDATE employee SET name='$ename',salary=$salary,job='$job',deptno=$deptno where empno=$id";
   // echo "Hi ". $sql;

    if ($conn->query($sql) === TRUE) {
        $msg= "1";
    } else {
        $msg= "0";
    }

}
?>
<head>
    <meta charset="UTF-8">
    <title>Add New Employee</title>
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>

    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

</head>
<body>
<header>
    <nav>
        <?php
        include "header.php";
        ?>
    </nav>
</header>
<div class="container-fluid">
<form action="updateEmp.php" method="post">


    <div class="row">
        <div class="col-md-4">
        </div>
        <div class="col-md-4">
            <label for="txtId">ID</label>
            <input type="text" name="txtId" id="txtId" value=<?php echo "'".$id."'";?> class="form-control">
            <input type="submit" value="Search" class="btn btn-info">
            <label for="txtId">Name</label>
            <input type="text" name="txtName" value=<?php echo "'".$ename."'";?>  id="txtName"  class="form-control">

            <label for="txtId">Salary</label>
            <input type="text" name="txtSalary"
                   value=<?php echo "'".$salary."'";?>
                   id="txtSalary"  class="form-control">

            <label for="txtId">Job</label>
            <input type="text" name="txtJob"
                   value=<?php echo "'".$job."'";?>
                   id="txtJob"  class="form-control">

            <label for="txtId">Dept</label>

           <select name="txtDept"  class="form-control">
               <?php
               $sql="select * from department";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
// output data of each row
    while($row = $result->fetch_assoc()) {
        if($row['deptno']==$deptno)
        echo "<option selected value=".$row['deptno'].">".$row['name']."</option>";
        else
            echo "<option  value=".$row['deptno'].">".$row['name']."</option>";

    }


} else {
    echo "0 results";
}
$conn->close();
?>
               ?>



           </select>



            <input type="submit" value="Add Record" class="btn btn-success btn-lg">

            <?php
            if (isset($msg))
                if($msg=="1")
            echo "<div class='alert alert-success'>Record has been updated</div>";
            else
                echo "<div class='alert alert-danger'>Record can't be update</div>";
            ?>


        </div>
        </div>
</form>
</div>



</body>

</html>