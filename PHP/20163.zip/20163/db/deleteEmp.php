
<html>

<?php

include "db.php";

if (isset($_POST["txtId"])) {
    $id = $_POST["txtId"];
    $msg="";

    $sql="DELETE FROM  employee WHERE empno=$id";


//echo $sql;

    if ($conn->query($sql) === TRUE) {
        $msg= "1";
    } else {
        $msg= "0";
    }

    $conn->close();

}
?>
<head>
    <meta charset="UTF-8">
    <title>Add New Employee</title>
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>

    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

</head>
<body>
<header>
    <nav>
        <?php
        include "header.php";
        ?>
    </nav>
</header>
<div class="container-fluid">
    <form action="deleteEmp.php" method="post">


        <div class="row">
            <div class="col-md-4">
            </div>
            <div class="col-md-4">
                <label for="txtId">ID</label>
                <input type="text" name="txtId" id="txtId"  class="form-control">


                <input type="submit" value="Delete Record" class="btn btn-danger btn-lg">

                <?php
                if (isset($msg))
                    if($msg=="1")
                        echo "<div class='alert alert-success'>Record has been deleted</div>";
                    else
                        echo "<div class='alert alert-danger'>Record can't be delete</div>";
                ?>


            </div>
        </div>
    </form>
</div>



</body>

</html>