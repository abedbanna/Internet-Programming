<?php
/**
 * Created by PhpStorm.
 * User: abanna
 * Date: 7/12/2017
 * Time: 8:46 AM
 */
$username=$_POST['txtUserName'];
$password=$_POST['txtPassword'];

$fname=$_POST['txtFName'];
$lname=$_POST['txtLName'];
$role=$_POST['lstRole'];
$dob=$_POST['txtDob'];
$gender=$_POST['rdoGender'];
?>

<table border="4">
    <tr><td>Username</td><td><?php echo $username?></td></tr>
    <tr><td>Password</td><td><?php echo $password?></td></tr>
    <tr><td>First Name</td><td><?php echo $fname?></td></tr>
    <tr><td>Last Name</td><td><?php echo $lname?></td></tr>
    <tr><td>Date of Birth</td><td><?php echo $dob?></td></tr>
    <tr><td>Gender</td><td><?php echo $gender?></td></tr>
</table>


