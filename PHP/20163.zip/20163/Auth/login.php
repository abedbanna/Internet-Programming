<?php
/**
 * Created by PhpStorm.
 * User: abanna
 * Date: 7/10/2017
 * Time: 8:59 AM
 */
$u=$_GET['txtUserName'];
$p=$_GET['txtPassword'];
$role=$_GET['lstRole'];
if($role=="U")
    echo "<h1>Welcome User: ". $u."</h1>";
else
    echo "<h1>Welcome Admin: ". $u."</h1>";

