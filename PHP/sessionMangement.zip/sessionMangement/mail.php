<?php
/**
 * Created by PhpStorm.
 * User: abanna
 * Date: 5/17/2017
 * Time: 7:31 AM
 */
session_start();
if(!isset($_SESSION['name'])|| !isset($_SESSION['username']))
    header('Location:https://localhost/sessionMangement/login.html');
//----------------------------------------------

 if($_SESSION['role']==1)
    echo "Welcome ya " . $_SESSION['name'] . "<br> Your Role is Admin";
 else
     echo "Welcome ya " . $_SESSION['name'] . "<br> YOur Role is Normal User";


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "auth";



// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
#step 2 Execute Sql
$sql ="";
if ($_SESSION['role']==1)
    $sql ="select * from emails";
else
    $sql ="select * from emails where user_id=".  $_SESSION['user_id'];

$result = $conn->query($sql);
#3- handle results
if ($result->num_rows > 0) {
// output data of each row

    echo "<table width='100%' border='5'>
<thead>
<tr>
<td>Title</td>
<td>Desc</td>
</tr>
</thead>";

    while($row = $result->fetch_assoc()) {

       echo "<tr><td>".$row['title']."</td>"."<td>".$row['descr']."</td></tr>";

    }
} else {
  echo '<h1>NO Emails</h1>';
}
echo '</table>';
//4- Close Connection
$conn->close();
//json_encode($result);
?>

