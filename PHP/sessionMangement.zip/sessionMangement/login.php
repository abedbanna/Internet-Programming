<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "auth";
$uname=$_POST['txtUserName'];
$pass=$_POST['txtPassword'];


// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
#step 2 Execute Sql
$sql = "select * from users WHERE username like'".$uname."' AND password like'".$pass."'";
$result = $conn->query($sql);
#3- handle results
if ($result->num_rows > 0) {
// output data of each row
    while($row = $result->fetch_assoc()) {
        $_SESSION['name']=$row['name'];
        $_SESSION['username']=$row['username'];
        $_SESSION['role']=$row['role'];
        $_SESSION['user_id']=$row['id'];

        header('Location:https://localhost/sessionMangement/mail.php');

    }
} else {
    header('Location:https://localhost/sessionMangement/login.html');
}
//4- Close Connection
$conn->close();
//json_encode($result);
?>