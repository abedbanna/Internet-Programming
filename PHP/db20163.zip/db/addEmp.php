<html>

<?php

    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "tiger";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_POST["txtId"])) {
    $id = $_POST["txtId"];
    $ename = $_POST['txtName'];
    $salary = $_POST['txtSalary'];
    $job = $_POST['txtJob'];
    $dept = $_POST['txtDept'];


$msg="";

    $sql = "INSERT INTO employee (empno, name, job,salary,deptno)".
"VALUES (" .$id. ",'".$ename."','".$job."',".$salary.",".$dept.");";

//echo $sql;

    if ($conn->query($sql) === TRUE) {
        $msg= "1";
    } else {
        $msg= "0";
    }

    $conn->close();

}
?>
<head>
    <meta charset="UTF-8">
    <title>Add New Employee</title>
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>

    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

</head>
<body>
<header>
    <nav>
        <ul class="nav nav-pills">
            <li role="presentation" class="active"><a href="allemps.php">All Emp</a></li>
            <li role="presentation"><a href="addEmp.php">Add New Employee</a></li>
            <li role="presentation"><a href="#">Update Employee</a></li>
        </ul>
    </nav>
</header>
<div class="container-fluid">
<form action="addEmp.php" method="post">


    <div class="row">
        <div class="col-md-4">
        </div>
        <div class="col-md-4">
            <label for="txtId">ID</label>
            <input type="text" name="txtId" id="txtId"  class="form-control">

            <label for="txtId">Name</label>
            <input type="text" name="txtName" id="txtName"  class="form-control">

            <label for="txtId">Salary</label>
            <input type="text" name="txtSalary" id="txtSalary"  class="form-control">

            <label for="txtId">Job</label>
            <input type="text" name="txtJob" id="txtJob"  class="form-control">

            <label for="txtId">Dept</label>

           <select name="txtDept" class="form-control">
               <?php
               $sql="select * from department";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
// output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<option value=".$row['deptno'].">".$row['name']."</option>";

    }


} else {
    echo "0 results";
}
$conn->close();
?>
               ?>



           </select>



            <input type="submit" value="Add Record" class="btn btn-success btn-lg">

            <?php
            if (isset($msg))
                if($msg=="1")
            echo "<div class='alert alert-success'>Record has been added</div>";
            else
                echo "<div class='alert alert-danger'>Record can't be added</div>";
            ?>


        </div>
        </div>
</form>
</div>



</body>

</html>