/**
 * Created by abanna on 4/3/2017.
 */
class Shape
{
    constructor(h,w)
    {
        this.h=h;
        this.w=w;
    }
    print()
    {
        console.log('the width is ' , this.w,' the height is ', this.h );

    }
}
class Rectangle extends Shape
{
area()
{return this.w *this.h;}
}

var obj=new Rectangle(10,20);
console.log(obj.area());