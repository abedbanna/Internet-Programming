/**
 * Created by abanna on 4/3/2017.
 */
import Person from './Person';
class Student extends Person
{
constructor(name ,dob,gender,level)
{
 super(name,dob,gender);
 this.level=level;


}
print()
{
    console.log("Student name is ",this.name ,'Student DOB is' ,this.dob ,'Student Gender is ' ,this.gender ,'Student Level is ' ,this.level);

}

}
var obj=new Student('Ahamad','20/12/1980','Male','freshMan');
obj.print();
