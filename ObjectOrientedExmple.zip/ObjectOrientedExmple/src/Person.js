/**
 * Created by abanna on 4/3/2017.
 */
class Person
{
    constructor(name ,dob,gender)
    {
        this.name=name;
        this.dob=dob;
        this.gender=gender;
    }
}
export default Person;