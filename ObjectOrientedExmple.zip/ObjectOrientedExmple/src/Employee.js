/**
 * Created by abanna on 4/3/2017.
 */
import Person from './Person';
class Employee extends Person
{
    constructor(name ,dob,gender,title)
    {
        super(name,dob,gender);
        this.title=title;


    }
    print()
    {
        console.log("Student name is ",this.name ,'Student DOB is' ,this.dob ,'Student Gender is ' ,this.gender ,'Student title is ' ,this.title);

    }

}
