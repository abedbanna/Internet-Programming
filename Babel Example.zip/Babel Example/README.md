## ES6 Tutorial

Start the tutorial [here](http://ccoenraets.github.io/es6-tutorial).